﻿To run this project in Visual Studio Code, open the LINQSamples.code-workspace
  When prompted to add "Required Assets", Click the 'Yes' button
  Run the project
  Check the DEBUG CONSOLE window for the output
To run this project in Visual Studio 2022, open the LINQSamples.sln
  Run the project
  A console window shows the output


SampleViewModel Samples
--------------------------------------------------
OrderBy() - Order products by Name
OrderByDescending() - Order products by name in descending order
OrderByTwoFields() - Order products by Color descending, then Name
OrderByTwoFieldsDescMethod() - Order products by Color descending, then Name Descending