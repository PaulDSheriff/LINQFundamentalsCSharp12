﻿To run this project in Visual Studio Code, open the LINQSamples.code-workspace
  When prompted to add "Required Assets", Click the 'Yes' button
  Run the project
  Check the DEBUG CONSOLE window for the output
To run this project in Visual Studio 2022, open the LINQSamples.sln
  Run the project
  A console window shows the output


SampleViewModel Samples
--------------------------------------------------
All() - Use All() to see if all items in a collection meet a specified condition
Any() - Use Any() to see if at least one item in a collection meets a specified condition
Contains() - Use the LINQ Contains operator to see if a collection contains a specific value
ContainsComparer() - Use the LINQ Contains operator to see if a collection contains a specific object using an EqualityComparer class to perform the comparison
